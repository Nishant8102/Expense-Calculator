# Simple Expense Calculator
It's A simple Expense Calculator Application made Through Tkinter.
It has Automatic History Saving Section When we Calculate the Total Expense from the Monthly Salary.
# How to use
First Input Your Income and Click on `set income` Button so that it can calulate the remaining Amount left with you after expense.
# Note 
This Application Runs on installation of tkinter
To install tkinter, you can run:
```bash
pip install tkinter
```
To Run the Python File 
```bash
python expensecalculator.py
```
# DO TRY IT AND BUY ME A COFFEE OR SAY THANKS 
<p>
<img src="https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/Hand%20gestures/Handshake.png" alt="Handshake" width="25" height="25" align="center"
</p>
