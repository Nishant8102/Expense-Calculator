# This is the small Projects in Python Language
